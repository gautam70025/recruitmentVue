export const global = {
    apiUrl: "http://pnrdassam.org/gaut/public/api/",
    imgUrl: "http://pnrdassam.org/gaut/storage/app"
};
