<template>
  <div class="contact container">
    <div class="row">
      <div class="col-md-7">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3582.4433093691873!2d91.83136001493467!3d26.11708500017356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375af5f8c1017537%3A0x548eb9004780ba78!2sState%20Institute%20of%20Panchayat%20%26%20Rural%20Development!5e0!3m2!1sen!2sin!4v1599292076008!5m2!1sen!2sin"
          width="100%"
          height="450"
          frameborder="0"
          style="border:0;"
          allowfullscreen
          aria-hidden="false"
          tabindex="0"
        ></iframe>
      </div>
      <div class="col-md-5">
        <div class="card-1-header">
          For any queries regarding online filling up of application, please contact us
          <hr />
        </div>
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-md-1 offset-md-2">
                <p>
                  <i class="fa fa-phone" style="color:#288003"></i>
                </p>
              </div>
              <div class="col-md-6 text-center">
                <p>12345678920</p>
                <p>12345678920</p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-1 offset-md-2">
                <p>
                  <i class="fa fa-envelope" style="color:darkorange"></i>
                </p>
              </div>
              <div class="col-md-6 text-center">
                <p>abc@gmail.com</p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-1 offset-md-2">
                <p>
                  <i class="fa fa-clock-o" style="color:mediumvioletred"></i>
                </p>
              </div>
              <div class="col-md-6 text-center">
                <p>10 AM - 5 PM</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.container-fluid {
  padding-left: 0px;
  padding-right: 0px;
  overflow: hidden;
}
.contact {
  margin-top: 40px;
}
.card-1-header {
  padding: 20px;
  font-size: 16px;
  font-weight: 500;
}
.card {
  border: 1px solid rgb(30 77 146);
  background: aliceblue;
  color: rgb(30 70 146 / 1);
  font-weight: 600;
}
</style>