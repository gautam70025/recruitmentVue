<template id="">
  <div class="container-fluid">
    <form class="detail_form" @submit.prevent="onNext">
    <div class="card step-1">
      <div class="card-header">
        Document Upload <span
                class="note"
              >(*) Fields are mandatory</span>
      </div>
      <div class="card-body">


          <div class="row">
            <div class="col-md-4 offset-md-2">
              <div class="form-group">
                <label for="document_name">Document Name<span class="star">*</span></label>
                <input type="text" class="form-control" name="" value="Passport Photo" v-model="document_name_1" disabled>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="document_file">Upload Document<span class="star">*(MAX:50KB)</span></label>
                <input type="file"  id="" placeholder="" @change="uploadFile1">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 offset-md-2">
              <div class="form-group">
                <label for="document_name">Document Name<span class="star">*</span></label>
                <input type="text" class="form-control" name="" value="Signature" v-model="document_name_2" disabled>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="document_file">Upload Document<span class="star">*(MAX:50KB)</span></label>
                <input type="file"  id="" placeholder="" @change="uploadFile2">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 offset-md-2">
              <div class="form-group">
                <label for="document_name">Document Name<span class="star">*</span></label>
                <input type="text" class="form-control" name="" value="Degree Marksheet" v-model="document_name_3" disabled>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="document_file">Upload Document<span class="star">*(MAX:50KB)</span></label>
                <input type="file"  id="" placeholder="" @change="uploadFile3">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 offset-md-2">
              <div class="form-group">
                <label for="document_name">Document Name<span class="star">*</span></label>
                <input type="text" class="form-control" name="" value="Degree Certificate" v-model="document_name_4" disabled>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="document_file">Upload Document<span class="star">*(MAX:50KB)</span></label>
                <input type="file"  id="" placeholder="" @change="uploadFile4">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 offset-md-2">
              <div class="form-group">
                <label for="document_name">Document Name<span class="star">*</span></label>
                <input type="text" class="form-control" name="" value="Caste Certificate" v-model="document_name_5" disabled>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="document_file">Upload Document<span class="star">*(MAX:50KB)</span></label>
                <input type="file"  id="" placeholder="" @change="uploadFile5">
              </div>
            </div>
          </div>


      </div>

      <div class="card-footer text-center">
        <button type="button" class="btn custom-prev" @click.prevent="onPrev">Prev</button>
        <button type="submit" class="btn custom-primary">Next</button>
      </div>
    </div>

  </form>
  </div>
</template>
<script>

export default{
    data(){
      return{
        document_name_1:'Passport Photo',
        document_file_1:null,
        document_name_2:'Signature',
        document_file_2:null,
        document_name_3:'Degree Marksheet',
        document_file_3:null,
        document_name_4:'Degree Certificate',
        document_file_4:null,
        document_name_5:'Caste Certificate',
        document_file_5:null,
        }
    },
    methods:{
      uploadFile1(event){
        this.document_file_1 = event.target.files[0];
      },
      uploadFile2(event){
        this.document_file_2 = event.target.files[0];
      },
      uploadFile3(event){
        this.document_file_3 = event.target.files[0];
      },
      uploadFile4(event){
        this.document_file_4 = event.target.files[0];
      },
      uploadFile5(event){
        this.document_file_5 = event.target.files[0];
      },
      onPrev(){
        this.$store.dispatch('changeStep', {next:0, user_id: this.$store.state.user.id});  
      },
      onNext(){
        const formData=new FormData();
        formData.append('document_name_1', this.document_name_1);
        formData.append('document_file_1', this.document_file_1);
        formData.append('document_name_2', this.document_name_2);
        formData.append('document_file_2', this.document_file_2);
        formData.append('document_name_3', this.document_name_3);
        formData.append('document_file_3', this.document_file_3);
        formData.append('document_name_4', this.document_name_4);
        formData.append('document_file_4', this.document_file_4);
        formData.append('document_name_5', this.document_name_5);
        formData.append('document_file_5', this.document_file_5);
        // const formData={
        //   document_name_1:this.document_name_1,
        //   document_file_1:this.document_file_1,
        //   document_name_2:this.document_name_2,
        //   document_file_2:this.document_file_2,
        //   document_name_3:this.document_name_3,
        //   document_file_3:this.document_file_3,
        //   document_name_4:this.document_name_4,
        //   document_file_4:this.document_file_4,
        //   document_name_5:this.document_name_5,
        //   document_file_5:this.document_file_5,
        // }

        this.$store.dispatch('documentSave',formData);
      }
    }
  }
</script>

<style media="screen">
.form-group span {
  color: red;
  font-size: 12px;
}
.note {
  color: #007bff;
  background: yellow;
  font-size: 14px;
  padding: 2px 5px;
  width: fit-content;
}
</style>
