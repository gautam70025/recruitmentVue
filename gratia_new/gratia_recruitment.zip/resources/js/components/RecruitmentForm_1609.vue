<template>
  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 text-center">
            <div class="card-optional px-0 pt-4 pb-0 mt-3 mb-3">
                <h3 id="heading">Fill up the details step by step</h3><br>
                <ul id="progressbar">
                    <li id="account" :class="{active:step==1}"><strong>Account</strong></li>
                    <li id="personal"><strong>Personal</strong></li>
                    <li id="payment"><strong>Image</strong></li>
                    <li id="confirm"><strong>Finish</strong></li>
                </ul>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100" :style="{width:barWidth+'%'}"></div>
                </div>

            </div>
        </div>
    </div>
    <form class="detail_form" @submit.prevent="onSubmit">
    <div class="card step-1" v-if="step==0">
      <div class="card-header">
        Permanent Address
      </div>
      <div class="card-body">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="village_town">Village/Town</label>
                <input type="text" class="form-control" id="" placeholder="" v-model="village_town">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="post_office">P.O.</label>
                <input type="text" class="form-control" id="" placeholder="" v-model="post_office">
              </div>
            </div>
          </div>
      </div>
      <div class="card-header">
        Correspondence Address
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="village_town">Village/Town</label>
              <input type="text" class="form-control" id="" placeholder="" v-model="village_town">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="post_office">P.O.</label>
              <input type="text" class="form-control" id="" placeholder="" v-model="post_office">
            </div>
          </div>
        </div>
      </div>
      <div class="card-footer text-center">
        <button type="button" class="btn btn-primary" @click.prevent="onNext">Next</button>
      </div>
    </div>
    <div class="card step-2" v-if="step==1">
      <div class="card-header">
        Post Applied
      </div>
      <div class="card-body">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="post_applied">Post Applied</label>
                <input type="text" class="form-control" id="" placeholder="" v-model="post_applied">
              </div>
            </div>
         </div>

      </div>

      <div class="card-footer text-center">
        <button type="button" class="btn btn-warning" @click.prevent="onPrev">Prev</button>
        <button type="button" class="btn btn-primary" @click.prevent="onNext">Next</button>
      </div>
    </div>
  </form>

</div>
</template>

<script>
export default {
  props: ["app"],
  data(){
    return{
      step:0,
      barWidth:0
    }
  },
  methods:{
    onPrev(){
      this.barWidth-=25
      console.log(this.barWidth);

      this.step--
    },
    onNext(){
      this.barWidth+=25
      this.step++
    }
  }
};
</script>
<style media="screen">
h3#heading{
  text-transform: uppercase;
  color: #1e4d92
}
.card-optional {
  z-index: 0;
  border: none;
  position: relative
}


#progressbar {
  margin-bottom: 30px;
  overflow: hidden;
  color: lightgrey;
  margin-left: -35px;
}

#progressbar .active {
  color: #673AB7
}

#progressbar li {
  list-style-type: none;
  font-size: 15px;
  width: 25%;
  float: left;
  position: relative;
  font-weight: 400
}

#progressbar #account:before {
  font-family: FontAwesome;
  content: "\f13e"
}

#progressbar #personal:before {
  font-family: FontAwesome;
  content: "\f007"
}

#progressbar #payment:before {
  font-family: FontAwesome;
  content: "\f030"
}

#progressbar #confirm:before {
  font-family: FontAwesome;
  content: "\f00c"
}

#progressbar li:before {
  width: 50px;
  height: 50px;
  line-height: 45px;
  display: block;
  font-size: 20px;
  color: #ffffff;
  background: lightgray;
  border-radius: 50%;
  margin: 0 auto 10px auto;
  padding: 2px
}

#progressbar li:after {
  content: '';
  width: 100%;
  height: 2px;
  background: lightgray;
  position: absolute;
  left: 0;
  top: 25px;
  z-index: -1
}

#progressbar li.active:before,
#progressbar li.active:after {
  background: #673AB7
}

.progress {
  height: 20px
}

.progress-bar {
  background-color: #673AB7
}

.fit-image {
  width: 100%;
  object-fit: cover
}
</style>
