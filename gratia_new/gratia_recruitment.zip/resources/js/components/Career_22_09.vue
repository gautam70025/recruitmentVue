<template>
  <div class="career container-fluid">
    <div class="career-content">
      <div class="row">
        <div class="col-md-10 offset-md-1 border-custom">
          <div class="career-header">
            <p style="font-weight:600">
              Advertisement No. : 123456
              <span>
                <a href>
                  <i class="fa fa-download"></i>
                </a>
              </span>
            </p>

            <p style="font-weight:600">
              Application Start Date : 01.01.2020

            </p>
            <p style="font-weight:600">
              Application End Date : 01.01.2020

            </p>
          </div>
          <br />
          <table class="table">
            <tr class="text-center tr-background">
              <th>Vacancy No.</th>
              <th>Programme</th>
              <th>Name of Posts</th>

              <th>Apply Link</th>
            </tr>
            <tr class="text-center">
              <th>12345678</th>
              <th>
                <div class="form-group">
                  <select class="form-control" name="" @change="changePosts" v-model="programme">
                    <!-- <option value="programme" v-for="programme in Object.keys(posts)">{{programme}}</option> -->
                    <!-- <option selected disabled>Select Programme</option> -->
                    <option value="" disabled selected>Select Programme</option>

                    <option :value="key" v-for="(post,key) in posts" :key="key">{{key}}</option>

                  </select>
                </div>
              </th>
              <th>
                <div class="form-group">
                  <select class="form-control" name="" v-model="post">
                    <option value="" selected disabled>Select Post</option>
                    <option :value="post.name_of_post" v-for="post in filteredPost">{{post.name_of_post}}</option>
                  </select>
                </div>
              </th>
              <th>
                <router-link to="/login" class="routerlink" >Apply Link</router-link>
              </th>
            </tr>

          </table>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {global} from '../global';
export default {
  data(){
    return {
      posts:null,
      post:'',
      programme:'',
      filteredPost:null
    }
  },
  methods:{
    changePosts(){
      // console.log('event',this.programme);
      // console.log(this.posts[this.programme]);
      this.filteredPost=this.posts[this.programme]
      // this.filteredPost=this.posts.filter(function(value){
      //  return value.programme == this.programme;
      //  });
    }
  },
  created(){
  },
  // computed:{
  //   post(){
  //     return Object.values(Object.keys(this.programme));
  //   }
  // },
  mounted(){
    axios
        .get(global.apiUrl + "get_job_posts")
        .then(res => {
          this.posts=res.data.job_posts
        })
        .catch(errors => {
            console.log(errors);
        });
  }
};
</script>
<style scoped>
.career-content {
  margin-top: 40px;
  text-align: center;
}
.career-content .row .border-custom {
  border: 1px solid #1e4d92;
  box-shadow: 1px 1px 8px 1px grey;
  padding: 35px;
}
.tr-background {
  background: #d2d2d28c;
}
tr th {
  border: none;
  font-size: 14px;
}
.routerlink {
  text-decoration: none;
}
</style>
