<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card box-card">
          <div class="card-header bg-primary">User Registration form</div>
          <div class="card-body">
            <p
              class="note"
            >*An email and a message containing the user id and password will be sent to your respective email id and phone number after succesful registration.</p>
            <form @submit.prevent="onRegister" id="demo-form">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="name">
                      Name
                      <span class="star">*</span>
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Enter Name"
                      id="name"
                      v-model="name"
                      :class="{
                                                border:
                                                    spanError.name == true ||
                                                    (val_errors &&
                                                        val_errors.name != null)
                                            }"
                    />
                    <span>{{ errors.name }}</span>
                    <span v-if="val_errors && val_errors.name">x {{ val_errors.name[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="email">
                      Email Id
                      <span class="star">*</span>
                    </label>
                    <input
                      type="email"
                      class="form-control"
                      placeholder="Enter Email"
                      id="email"
                      v-model="email"
                      :class="{
                                                border:
                                                    spanError.email == true ||
                                                    (val_errors &&
                                                        val_errors.email !=
                                                            null && email_errors!=null)
                                            }"
                    />
                    <span>{{ errors.email }}</span>
                    <span v-if="email_errors">x {{ email_errors }}</span>

                    <span
                      v-if="
                                                val_errors && val_errors.email
                                            "
                    >x {{ val_errors.email[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="phone_no">
                      Phone No
                      <span class="star">*</span>
                    </label>
                    <input
                      type="number"
                      class="form-control"
                      placeholder="Enter Phone No"
                      id="phone_no"
                      v-model="phone_no"
                      :class="{
                                                border:
                                                    spanError.phone_no ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.phone_no !=
                                                            null)
                                            }"
                    />
                    <span>{{ errors.phone_no }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.phone_no
                                            "
                    >
                      x
                      {{ val_errors.phone_no[0] }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="dob">
                      DOB
                      <span class="star">*</span>
                    </label>
                    <input
                      type="date"
                      class="form-control"
                      placeholder="Enter DOB"
                      id="dob"
                      v-model="dob"
                      :class="{
                                                border:
                                                    spanError.dob == true ||
                                                    (val_errors &&
                                                        val_errors.dob != null)
                                            }"
                    />
                    <span>{{ errors.dob }}</span>
                    <span v-if="val_errors && val_errors.dob">x {{ val_errors.dob[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="gender">
                      Gender
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="gender"
                      v-model="gender"
                      :class="{
                                                border:
                                                    spanError.gender == true ||
                                                    (val_errors &&
                                                        val_errors.gender !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Others">Others</option>
                    </select>
                    <span>{{ errors.gender }}</span>
                    <span
                      v-if="
                                                val_errors && val_errors.gender
                                            "
                    >x {{ val_errors.gender[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="religion">
                      Religion
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="religion"
                      v-model="religion"
                      :class="{
                                                border:
                                                    spanError.religion ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.religion !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select Religion</option>
                      <option value="Hindu">Hindu</option>
                      <option value="Christian">Christian</option>
                      <option value="Buddhism">Budhhism</option>
                      <option value="Islam">Islam</option>
                    </select>
                    <span>{{ errors.religion }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.religion
                                            "
                    >
                      x
                      {{ val_errors.religion[0] }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="nationality">
                      Nationality
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="nationality"
                      v-model="nationality"
                      :class="{
                                                border:
                                                    spanError.nationality ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.nationality !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select Nationality</option>
                      <option value="Indian">Indian</option>
                      <option value="Others">Others</option>
                    </select>
                    <span>{{ errors.nationality }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.nationality
                                            "
                    >
                      x
                      {{
                      val_errors.nationality[0]
                      }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="caste">
                      Caste
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="caste"
                      v-model="caste"
                      :class="{
                                                border:
                                                    spanError.caste == true ||
                                                    (val_errors &&
                                                        val_errors.caste !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select Caste</option>
                      <option value="General">General</option>
                      <option value="OBC">OBC</option>
                      <option value="SC">SC</option>
                      <option value="ST">ST</option>
                    </select>
                    <span>{{ errors.caste }}</span>
                    <span
                      v-if="
                                                val_errors && val_errors.caste
                                            "
                    >x {{ val_errors.caste[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="gender">
                      Differently Abled?
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="pwd"
                      v-model="pwd"
                      :class="{
                                                border:
                                                    spanError.pwd == true ||
                                                    (val_errors &&
                                                        val_errors.pwd != null)
                                            }"
                    >
                      <option value disabled selected>Select yes/no</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                    <span>{{ errors.pwd }}</span>
                    <span v-if="val_errors && val_errors.pwd">x {{ val_errors.pwd[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4" v-if="pwd == 'Yes'">
                  <div class="form-group">
                    <label for="gender">
                      Category of PWD
                      <span class="star">*</span>
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="PWD Category"
                      id="pwd_category"
                      list="lpwd_category"
                      v-model="pwd_category"
                      :class="{
                                                border:
                                                    spanError.pwd_category ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.pwd_category !=
                                                            null)
                                            }"
                    />
                    <datalist id="lpwd_category">
                      <option value disabled selected>Select yes/no</option>
                      <option value="OH">
                        Orthopaedically
                        Handicapped
                      </option>
                      <option value="HI">Hearing Impairment</option>
                      <option value="VI">Visually Impaired</option>
                    </datalist>
                    <span>{{ errors.pwd_category }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.pwd_category
                                            "
                    >
                      x
                      {{
                      val_errors.pwd_category[0]
                      }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="existing_employee">
                      Working as a contractual/casual
                      employee in P&RD
                      <span
                        class="star"
                      >*</span>
                    </label>

                    <select
                      class="form-control"
                      id="existing_employee"
                      v-model="existing_employee"
                      :class="{
                                                border:
                                                    spanError.existing_employee ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.existing_employee !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select yes/no</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                    <span>
                      {{
                      errors.existing_employee
                      }}
                    </span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.existing_employee
                                            "
                    >
                      x
                      {{
                      val_errors.existing_employee[0]
                      }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4" v-if="existing_employee == 'Yes'">
                  <div class="form-group">
                    <label for="existing_emp_year">No. of years working in PNRD</label>

                    <input
                      type="number"
                      class="form-control"
                      id="existing_emp_year"
                      v-model="existing_emp_year"
                      placeholder="Enter Year"
                      :class="{
                                                border:
                                                    spanError.existing_emp_year ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.existing_emp_year !=
                                                            null)
                                            }"
                    />

                    <span>
                      {{
                      errors.existing_emp_year
                      }}
                    </span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.existing_emp_year
                                            "
                    >
                      x
                      {{
                      val_errors.existing_emp_year[0]
                      }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="ews">
                      Do you belong to EWS (Economically
                      Weaker Sections) Category
                      <span
                        class="star"
                      >*</span>
                    </label>

                    <select
                      class="form-control"
                      id="ews"
                      v-model="ews"
                      :class="{
                                                border:
                                                    spanError.ews == true ||
                                                    (val_errors &&
                                                        val_errors.ews != null)
                                            }"
                    >
                      <option value disabled selected>Select yes/no</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                    <span>{{ errors.ews }}</span>
                    <span v-if="val_errors && val_errors.ews">x {{ val_errors.ews[0] }}</span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="ex_serviceman">
                      Ex Serviceman
                      <span class="star">*</span>
                    </label>

                    <select
                      class="form-control"
                      id="ex_serviceman"
                      v-model="ex_serviceman"
                      :class="{
                                                border:
                                                    spanError.ex_serviceman ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.ex_serviceman !=
                                                            null)
                                            }"
                    >
                      <option value disabled selected>Select yes/no</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                    <span>{{ errors.ex_serviceman }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.ex_serviceman
                                            "
                    >
                      x
                      {{
                      val_errors.ex_serviceman[0]
                      }}
                    </span>
                  </div>
                </div>

                <!-- <div class="col-md-4">
                  <div class="form-group">
                    <label for="password">
                      Password
                      <span class="star">*</span>
                    </label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter Password"
                      id="password"
                      v-model="password"
                      :class="{
                                                border:
                                                    spanError.password ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.password !=
                                                            null)
                                            }"
                    />
                    <span>{{ errors.password }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.password
                                            "
                    >
                      x
                      {{ val_errors.password[0] }}
                    </span>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="password">
                      Confirm Password
                      <span class="star">*</span>
                    </label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter Password Again"
                      id="confirm_password"
                      v-model="confirm_password"
                      :class="{
                                                border:
                                                    spanError.confirm_password ==
                                                        true ||
                                                    (val_errors &&
                                                        val_errors.password !=
                                                            null)
                                            }"
                    />
                    <span>{{ errors.confirm_password }}</span>
                    <span
                      v-if="
                                                val_errors &&
                                                    val_errors.password
                                            "
                    >
                      x
                      {{ val_errors.password[0] }}
                    </span>
                  </div>
                </div> -->
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="captcha-class">
                    <p>
                      {{captcha_code}}
                      <span>
                        <button type="button" class="btn btn-sm" @click="reloadCaptcha">
                          <i class="fa fa-refresh"></i>
                        </button>
                      </span>
                    </p>
                  </div>
                  <div class="form-group">
                    <input
                      type="number"
                      class="form-control"
                      placeholder="Confirm Captcha"
                      id="confirm_captcha"
                      v-model="confirm_captcha"
                      :class="{
                                                border:
                                                    spanError.confirm_captcha ==
                                                        true

                                            }"
                    />
                    <span>{{ errors.confirm_captcha }}</span>
                  </div>
                </div>
                <div class="col-md-12 text-center">
                  <hr />
                  <button type="submit" class="btn custom-success">Register</button>
                  <br />
                  <br />
                  <p>
                    <router-link to="/login">Already registered ? Login here</router-link>
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import swal from "sweetalert";
import { global } from "../global.js";
import Nprogress from "nprogress";
import "nprogress/nprogress.css";
export default {
  data() {
    return {
      name: "",
      email: "",
      phone_no: "",
      password: "",
      confirm_password: "",
      dob: "",
      gender: "",
      religion: "",
      nationality: "",
      caste: "",
      pwd: "",
      pwd_category: "",
      existing_employee: "",
      existing_emp_year: "",
      ews: "",
      ex_serviceman: "",
      errors: {},
      spanError: {},
      global: global,
      confirm_captcha: "",
      first_no: null,
      second_no: null,
      captcha_code: null,
    };
  },
  created() {
    // this.$nextTick(function () {
    //   grecaptcha.render("recaptcha-main");
    // });
  },
  methods: {
    reloadCaptcha() {
      this.first_no = Math.floor(Math.random() * 10) + 1;
      this.second_no = Math.floor(Math.random() * 99) + 1;
      this.captcha_code = this.first_no + "+" + this.second_no;
    },
    onRegister() {
      this.errors = {};
      if (!this.name.length) {
        this.errors.name = "x This field is required.";
        this.spanError.name = true;
      } else {
        this.errors.name = null;
        delete this.errors["name"];
        this.spanError.name = false;
      }
      if (!this.email.length) {
        this.errors.email = "x This field is required.";
        this.spanError.email = true;
      } else {
        this.errors.email = null;
        delete this.errors["email"];

        this.spanError.email = false;
      }
      if (!this.phone_no.length || this.phone_no.length != 10) {
        this.errors.phone_no = "x This field is required.";
        this.spanError.phone_no = true;
      } else {
        this.errors.phone_no = null;
        delete this.errors["phone_no"];

        this.spanError.phone_no = false;
      }
      if (!this.dob.length) {
        this.errors.dob = "x This field is required.";
        this.spanError.dob = true;
      } else {
        this.errors.dob = null;
        delete this.errors["dob"];

        this.spanError.dob = false;
      }
      if (!this.gender.length) {
        this.errors.gender = "x This field is required.";
        this.spanError.gender = true;
      } else {
        this.errors.gender = null;
        delete this.errors["gender"];

        this.spanError.gender = false;
      }
      if (!this.religion.length) {
        this.errors.religion = "x This field is required.";
        this.spanError.religion = true;
      } else {
        this.errors.religion = null;
        delete this.errors["religion"];

        this.spanError.religion = false;
      }
      if (!this.nationality.length) {
        this.errors.nationality = "x This field is required.";
        this.spanError.nationality = true;
      } else {
        this.errors.nationality = null;
        delete this.errors["nationality"];

        this.spanError.nationality = false;
      }
      if (!this.caste.length) {
        this.errors.caste = "x This field is required.";
        this.spanError.caste = true;
      } else {
        this.errors.caste = null;
        delete this.errors["caste"];

        this.spanError.caste = false;
      }
      if (!this.pwd.length) {
        this.errors.pwd = "x This field is required.";
        this.spanError.pwd = true;
      } else {
        this.errors.pwd = null;
        delete this.errors["pwd"];

        this.spanError.pwd = false;
      }
      if (this.pwd == "Yes" && !this.pwd_category.length) {
        this.errors.pwd_category = "x This field is required.";
        this.spanError.pwd_category = true;
      } else {
        this.errors.pwd_category = null;
        delete this.errors["pwd_category"];

        this.spanError.pwd_category = false;
      }
      if (!this.existing_employee.length) {
        this.errors.existing_employee = "x This field is required.";
        this.spanError.existing_employee = true;
      } else {
        this.errors.existing_employee = null;
        delete this.errors["existing_employee"];

        this.spanError.existing_employee = false;
      }
      if (this.existing_employee == "Yes" && !this.existing_emp_year.length) {
        this.errors.existing_emp_year = "x This field is required.";
        this.spanError.existing_emp_year = true;
      } else {
        this.errors.existing_emp_year = null;
        delete this.errors["existing_emp_year"];

        this.spanError.existing_emp_year = false;
      }
      if (!this.ews.length) {
        this.errors.ews = "x This field is required.";
        this.spanError.ews = true;
      } else {
        this.errors.ews = null;
        delete this.errors["ews"];

        this.spanError.ews = false;
      }
      if (!this.ex_serviceman.length) {
        this.errors.ex_serviceman = "x This field is required.";
        this.spanError.ex_serviceman = true;
      } else {
        this.errors.ex_serviceman = null;
        delete this.errors["ex_serviceman"];

        this.spanError.ex_serviceman = false;
      }
      // if (
      //   !this.password.length ||
      //   !this.confirm_password ||
      //   this.password !== this.confirm_password
      // ) {
      //   this.errors.password = "x Passwords don't match.";
      //   this.errors.confirm_password = "x Passwords don't match.";
      //   this.spanError.confirm_password = true;
      //   this.spanError.password = true;
      // } else {
      //   delete this.errors["password"];
      //   delete this.errors["confirm_password"];
      //   this.spanError.confirm_password = false;
      //   this.spanError.password = false;
      // }
      if (this.confirm_captcha != this.first_no + this.second_no) {
        this.errors.confirm_captcha = "x Invalid Captcha.";
        this.spanError.confirm_captcha = true;
      } else {
        delete this.errors["confirm_captcha"];
        this.spanError.confirm_captcha = false;
      }
      if (Object.keys(this.errors).length == 0) {
        Nprogress.start();

        const data = {
          name: this.name,
          email: this.email,
          phone_no: this.phone_no,
          // password: this.password,
          dob: this.dob,
          gender: this.gender,
          religion: this.religion,
          nationality: this.nationality,
          caste: this.caste,
          pwd: this.pwd,
          pwd_category: this.pwd_category,
          existing_employee: this.existing_employee,
          existing_emp_year: this.existing_emp_year,
          ews: this.ews,
          ex_serviceman: this.ex_serviceman,
          captcha: this.captcha_code,
        };
        // console.log("ad", data);

        this.$store
          .dispatch("register", data)
          .then((result) => {
            Nprogress.done();

            swal("Done!", "Registration Completed", "success");
            this.$router.push("/login");
          })
          .catch((error) => {
            console.log("error");
          });
      }
    },
  },
  computed: {
    // captcha_code() {
    //   this.first_no = Math.floor(Math.random() * 10) + 1;
    //   this.second_no = Math.floor(Math.random() * 99) + 1;
    //   console.log(this.first_no);
    //   return this.first_no + "+" + this.second_no;
    // },
    val_errors() {
      return this.$store.state.register_errors;
      // if (this.$store.state.register_errors != null) {
      //   var err = this.$store.state.register_errors;
      //   err = Object.values(err);
      //   err = err.flat();
      //   return err;
      // }
    },
    email_errors() {
      return this.$store.state.register_email_errors;
    },
  },
  mounted() {
    this.reloadCaptcha();
    // grecaptcha.reset();
    // grecaptcha.ready(function () {
    //   grecaptcha.render("recaptcha-container", {
    //     sitekey: "6Lcqj8UZAAAAAKTrGTjXoYyAAutAQa1Xi9mWmkN8",
    //   });
    // });
    // console.log(global.gcp_site_key);
  },
};
</script>
<style scoped>
.card {
  margin-top: 20px;
}
.card-header {
  text-align: center;
  color: white;
  text-transform: uppercase;
  font-size: 18px;
}
.form-group span {
  color: red;
  font-size: 12px;
}
.border {
  border: 1px solid red !important;
}
.box-card {
  box-shadow: 1px 1px 8px 1px #5d5d5d5e;
}
.note {
  color: #007bff;
  background: yellow;
  font-size: 14px;
  padding: 2px 5px;
  width: fit-content;
}
</style
>>
