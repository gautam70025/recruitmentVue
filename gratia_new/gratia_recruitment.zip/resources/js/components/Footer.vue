<template>
  <div class="footer-area">
    <div class="container-fluid">
      <p style="float:left">© Copyright 2020. SIPRD</p>
      <p style="float:right">
        Design & developed by
        <a href="https://www.gratiatechnology.com">Gratia Technology PVT LTD.</a>
      </p>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style>
.footer-area {
  margin-top: 80px;
  background: #1e4d92;
  text-align: center;
  height: 50px;
  display: flex;
  align-items: center;
  /* justify-content: center; */
  /* position: absolute;
    bottom: 0;
    left: 0;
    width: 100%; */
}
.footer-area p {
  color: white;
  height: 20px;
  font-size: 14px;
}
.footer-area a {
  color: #fffc9b;
  text-decoration: none;
  background-color: transparent;
}
.footer-area a:hover {
  color: #fffc9b;
  text-decoration: none;
  background-color: transparent;
}
</style>
