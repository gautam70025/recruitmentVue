<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 offset-md-2">
        <div class="card">
          <div class="card-header bg-primary">User Registration form</div>
          <div class="card-body">
            <form @submit.prevent="onRegister" id="demo-form">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Enter Name"
                      id="name"
                      v-model="name"
                      :class="{
                                                border: spanError.name == true || (val_errors && val_errors.name!=null)
                                            }"
                    />
                    <span>{{ errors.name }}</span>
                    <span v-if="val_errors && val_errors.name">x {{ val_errors.name[0] }}</span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="email">Email Id</label>
                    <input
                      type="email"
                      class="form-control"
                      placeholder="Enter Email"
                      id="email"
                      v-model="email"
                      :class="{
                                                border: spanError.email == true || (val_errors && val_errors.email!=null)
                                            }"
                    />
                    <span>{{ errors.email }}</span>
                    <span v-if="val_errors && val_errors.email">x {{ val_errors.email[0] }}</span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="phone_no">Phone No</label>
                    <input
                      type="number"
                      class="form-control"
                      placeholder="Enter Phone No"
                      id="phone_no"
                      v-model="phone_no"
                      :class="{
                                                border:
                                                    spanError.phone_no == true || (val_errors && val_errors.phone_no!=null)
                                            }"
                    />
                    <span>{{ errors.phone_no }}</span>
                    <span v-if="val_errors && val_errors.phone_no">x {{ val_errors.phone_no[0] }}</span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter Password"
                      id="password"
                      v-model="password"
                      :class="{
                                                border:
                                                    spanError.password == true || (val_errors && val_errors.password!=null)
                                            }"
                    />
                    <span>{{ errors.password }}</span>
                    <span v-if="val_errors && val_errors.password">x {{ val_errors.password[0] }}</span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="password">Confirm Password</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="Enter Password Again"
                      id="confirm_password"
                      v-model="confirm_password"
                      :class="{
                                                border:
                                                    spanError.confirm_password ==
                                                    true || (val_errors && val_errors.password!=null)
                                            }"
                    />
                    <span>
                      {{
                      errors.confirm_password
                      }}
                    </span>
                    <span v-if="val_errors && val_errors.password">x {{ val_errors.password[0] }}</span>
                  </div>
                </div>
                <div class="col-md-12 text-center">
                  <div id="recaptcha-main" class="g-recaptcha" :data-sitekey="global.gcp_site_key"></div>
                  <hr />
                  <button type="submit" class="btn btn-success custom-success">Register</button>
                  <br />
                  <br />
                  <p>
                    <router-link to="/login">
                      Already registered ? Login
                      here
                    </router-link>
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
import swal from "sweetalert";
import { global } from "../global.js";

export default {
  data() {
    return {
      name: "",
      email: "",
      phone_no: "",
      password: "",
      confirm_password: "",
      errors: {},
      spanError: {},
      global: global,
    };
  },
  created() {
    this.$nextTick(function () {
      grecaptcha.render("recaptcha-main");
    });
    // grecaptcha.reset();
    // grecaptcha.ready(function () {
    //   grecaptcha.render("recaptcha-container", {
    //     sitekey: "6Lcqj8UZAAAAAKTrGTjXoYyAAutAQa1Xi9mWmkN8",
    //   });
    // });
  },
  methods: {
    // checkCaptcha(token) {
    //   console.log(token);
    //   if (token) {
    //     console.log(token);
    //   }
    // },
    // onloadCallback() {
    //   console.log("captcha");
    // },
    // onSubmit(token) {
    //   document.getElementById("demo-form").submit();
    // },
    onRegister() {
      this.errors = {};
      if (!this.name.length) {
        this.errors.name = "x This field is required.";
        this.spanError.name = true;
      } else {
        this.errors.name = null;
        delete this.errors["name"];
        this.spanError.name = false;
      }
      if (!this.email.length) {
        this.errors.email = "x This field is required.";
        this.spanError.email = true;
      } else {
        this.errors.email = null;
        delete this.errors["email"];

        this.spanError.email = false;
      }
      if (!this.phone_no.length || this.phone_no.length != 10) {
        this.errors.phone_no = "x This field is required.";
        this.spanError.phone_no = true;
      } else {
        this.errors.phone_no = null;
        delete this.errors["phone_no"];

        this.spanError.phone_no = false;
      }

      if (
        !this.password.length ||
        !this.confirm_password ||
        this.password !== this.confirm_password
      ) {
        this.errors.password = "x Passwords don't match.";
        this.errors.confirm_password = "x Passwords don't match.";
        this.spanError.confirm_password = true;
        this.spanError.password = true;
      } else {
        delete this.errors["password"];
        delete this.errors["confirm_password"];
        this.spanError.confirm_password = false;
        this.spanError.password = false;
      }
      if (grecaptcha.getResponse() == "") {
        swal("Error!", "You are not a human", "error");
      } else {
        if (Object.keys(this.errors).length == 0) {
          const data = {
            name: this.name,
            email: this.email,
            phone_no: this.phone_no,
            password: this.password,
            grecaptcha: grecaptcha.getResponse(),
          };
          // console.log("ad", data);

          this.$store
            .dispatch("register", data)
            .then((result) => {
              swal("Done!", "Registration Completed", "success");
              this.$router.push("/login");
            })
            .catch((error) => {
              console.log("error");
            });
        }
      }
    },
  },
  computed: {
    val_errors() {
      return this.$store.state.register_errors;
      // if (this.$store.state.register_errors != null) {
      //   var err = this.$store.state.register_errors;
      //   err = Object.values(err);
      //   err = err.flat();
      //   return err;
      // }
    },
  },
  mounted() {
    // grecaptcha.reset();
    // grecaptcha.ready(function () {
    //   grecaptcha.render("recaptcha-container", {
    //     sitekey: "6Lcqj8UZAAAAAKTrGTjXoYyAAutAQa1Xi9mWmkN8",
    //   });
    // });
    // console.log(global.gcp_site_key);
  },
};
</script>
<style scoped>
.card {
  margin-top: 40px;
}
.card-header {
  text-align: center;
  color: white;
  text-transform: uppercase;
  font-size: 20px;
}
.form-group span {
  color: red;
  font-size: 12px;
}
.border {
  border: 1px solid red !important;
}
</style
>>
