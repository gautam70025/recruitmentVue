<template>
  <div class="notifications">
    <div class="card custom-card">
      <div class="card-body">
        <p class="text-center">Notifications</p>
        <hr style="border-top:1px solid rgb(30 77 146 / 42%)" />
        <div class="news blur">
          <ul class="marquee slider">
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet Lorem ipsum dolor sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet Lorem ipsum dolor sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
            <li>
              <i class="fa fa-fire"></i> &nbsp;Lorem ipsum dolor
              sit amet
              <span>
                <img src="../images/new.gif" alt="img" width="50px" />
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
