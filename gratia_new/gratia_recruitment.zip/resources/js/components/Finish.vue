<template id="">
<div class="container-fluid">
    <form class="detail_form" @submit.prevent="onSubmit">
      <div class="card step-1">
        <div class="card-header">
          Confirm Form Submission<span
                  class="note"
                >(*) Once submitted, you can't change or modify anything.</span>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          Personal Information
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-10">
            <tr>
              <th>Name</th>
              <th>Father Name</th>
              <th>Mother Name</th>
              <th>Permanent Address</th>
              <th>Present Address</th>
              <th>Present Address</th>
            </tr>
            </div>
          </div>
        </div>
        <div class="card-footer text-center">
          <button type="button" class="btn custom-prev" @click.prevent="onPrev">Prev</button>
          <button type="submit" class="btn custom-primary" @click.prevent="onNext">Next</button>
        </div>
      </div>



    </form>
</div>
</template>

<script>
import {global} from '../global';

import Nprogress from "nprogress";
import "nprogress/nprogress.css";
  export default{
    data(){
      return{

      }
    },
    methods:{
      onPrev(){
        this.$store.dispatch('changeStep', {next:0, user_id: this.$store.state.user.id});

      },
      onNext(){
          swal({
            title: "Final Submission",
            text: "Are you sure?",
            buttons: true,
          }).then((isConfirm) => {
            if (isConfirm) {
              Nprogress.start();

                this.$store.dispatch('changeStep', {next:200, user_id: this.$store.state.user.id})
                .then(()=>{
                  swal("Done!", "Form Submitted Successfully", "success");
                  Nprogress.done();

                });
            }
          });
      }
    },
    computed:{

    },
    created(){

    },
  }
</script>

<style >

</style>
