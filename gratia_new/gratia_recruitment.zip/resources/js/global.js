export const global = {
    apiUrl: "http://localhost:8000/api/",
};
