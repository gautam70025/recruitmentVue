
  <p>Hello <?php echo e($data['name']); ?>, you have been registered successfully for SIPRD Recruitment Portal.</p>
  <p>Your login details are stated below:</p>
  <p>User Id: <b><?php echo e($data['registration_no']); ?></b></p>
  <p>Password: <b><?php echo e($data['password']); ?></b></p>
<?php /**PATH D:\gratia_recruitment\resources\views/register_mail.blade.php ENDPATH**/ ?>