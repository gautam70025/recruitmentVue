<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Registration_detail;
use File;
use DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use App\Mail\RegistrationMail;

class AuthController extends Controller
{
    public function register(Request $request){

        $validate_data=$request->validate([
            'name'=>'required',
            'email'=>'email|required|unique:users',
            'phone_no'=>'numeric|required|unique:users',
            // 'password'=>'required',
            'captcha' =>'required'

        ]);

        DB::beginTransaction();

        try {
          $prev_user_details=User::orderBy('id', 'desc')->first();
          if($prev_user_details!=null){
            $registration_no='REGDSIPRD20'.(str_pad(number_format(substr($prev_user_details->registration_no,11))+1, 6, "0", STR_PAD_LEFT));
          }
          else{
            $registration_no='REGDSIPRD20000001';
          }
        $password_user=str_random(8);
        $password=Hash::make($password_user);
        $user=User::create($validate_data);
        $user->Update(['registration_no'=>$registration_no,'password'=>$password]);
        if($user){
             try {
               $mail_data=[
                 'name'=>$user->name,
                 'registration_no'=>$registration_no,
                 'password'=>$password_user
               ];
                Mail::to($user->email)->send(new RegistrationMail($mail_data));
                DB::commit();
             } catch (\Exception $e) {
                DB::rollback();
                return response()->json(['message'=>'Invalid Email', 'statusCode'=>422]);
             }
          }

            return response()->json(['message'=>'Registration Successful', 'statusCode'=>200]);
            } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['message'=>'Registration Failed', 'statusCode'=>502]);
            }
    }

    public function login(Request $request)
    {
         $validate_data=$request->validate([
            // 'email'=>'email|required|',
            'registration_no'=>'required',
            'password'=>'required',

        ]);
        // $validate_data['email']='gforgenius2@gmail.com';
        $validate_captcha=$request->validate(['captcha'=>'required']);
        if(!auth()->attempt($validate_data)){
            return response()->json(['message'=>'Invalid Credentials','statusCode'=>401]);
        }
        $accessToken=auth()->user()->createToken('authToken')->accessToken;
        return response(['user'=>auth()->user(), 'accessToken'=>$accessToken, 'statusCode'=>200]);


    }
    public function init()
    {
      $user=auth('api')->user();
      return response()->json(['user'=>$user], 200);
    }
}
