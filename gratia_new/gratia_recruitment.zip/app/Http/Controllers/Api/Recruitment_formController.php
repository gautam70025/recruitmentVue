<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\District;
use App\Block;
use App\Gram_panchyat;
use App\Personal_detail;
use App\Educational_qualification;
use App\Language_proficiency;
use DB;
use App\User;
use App\Job_post;
use App\Required_qualification;
use App\Diploma_name;
use App\Work_experience;
use App\Computer_skill;
use App\Document_save;
class Recruitment_formController extends Controller
{
    public function personal_info_save(Request $request)
    {
      $validate_data=$request->validate([
          'job_post_id'=>'required',
          // 'programme'=>'required',
          'father_name'=>'required',
          'mother_name'=>'required',
          'employment_reg_no'=>'required',
          'village_town'=>'required',
          'post_office'=>'required',
          'police_station'=>'required',
          'pincode'=>'required',
          'district_id'=>'required',
          'c_district_id'=>'required',
          'state'=>'required',
          'c_village_town'=>'required',
          'c_post_office'=>'required',
          'c_police_station'=>'required',
          'c_pincode'=>'required',
          'c_state'=>'required',
          'dob'=>'required',
          'gender'=>'required',
          'nationality'=>'required',
          // 'religion'=>'required',
          'caste'=>'required',
          'pwd'=>'required',
          // 'ews'=>'required',
          // 'ex_serviceman'=>'required',
          // 'existing_employee'=>'required',

      ]);

      // return auth('api')->user();
      // $user_id=auth('api')->user()->id;
      $user_id=$request->user_id;
      $validate_data['user_id']=$user_id;
      $validate_data['pwd_category']=$request->pwd_category;
      $validate_data['gram_panchyat_id']=$request->gram_panchyat_id;
      $validate_data['block_id']=$request->block_id;
      $validate_data['municipality']=$request->municipality;
      $validate_data['ward_no']=$request->ward_no;
      $validate_data['c_gram_panchyat_id']=$request->c_gram_panchyat_id;
      $validate_data['c_block_id']=$request->c_block_id;
      $validate_data['c_municipality']=$request->c_municipality;
      $validate_data['c_ward_no']=$request->c_ward_no;
      $validate_data['pwd_category']=$request->pwd_category;
      $validate_data['pwd_category']=$request->pwd_category;
      // $validate_data['existing_emp_year']=$request->existing_emp_year;

        $personal_details=Personal_detail::updateOrCreate(['user_id'=>$user_id,'job_post_id'=>$validate_data['job_post_id']],$validate_data);

          if($personal_details){
            return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
          }

          return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);

    }
    public function get_personal_info(Request $request)
    {
      if($request->user_id!=null){
        $personal_details=Personal_detail::where('user_id', $request->user_id)->with(['district','job_post','gram_panchyat','block','c_district','c_gram_panchyat','c_block'])->first();
      }

      return response()->json(['personal_details'=>$personal_details, 'statusCode'=>200]);

    }
    public function get_educational_qualifications(Request $request)
    {
      if($request->user_id!=null&&$request->job_post_id!=null){
        $educational_qualifications=Educational_qualification::where('user_id', $request->user_id)->where('job_post_id', $request->job_post_id)->get();
      }

      return response()->json(['educational_qualifications'=>$educational_qualifications, 'statusCode'=>200]);

    }

    public function change_step(Request $request)
    {
      // return $request->all();
      // $user=User::findOrFail(auth('api')->user()->id);
      $user=User::findOrFail($request->user_id);

      if($request->next==1){

        $user->step=$user->step+1;
        $user->save();
      }
      if($request->next==0){
        $user->step=$user->step-1;
        $user->save();
      }
      return response()->json(['user'=>$user, 'statusCode'=>200]);
    }
    public function language_proficiency_save(Request $request)
    {
      // return $request->all();
      $validate_data=$request->validate([
          'job_post_id'=>'required',
          'eng_lang'=>'required',
          'ben_lang'=>'required',
          'ass_lang'=>'required',
          'bodo_lang'=>'required',
          'eng_read'=>'required',
          'eng_write'=>'required',
          'eng_speak'=>'required',
          'ass_read'=>'required',
          'ass_write'=>'required',
          'ass_speak'=>'required',
          'ben_read'=>'required',
          'ben_write'=>'required',
          'ben_speak'=>'required',
          'bodo_read'=>'required',
          'bodo_write'=>'required',
          'bodo_speak'=>'required',

      ]);

      // $user_id=auth('api')->user()->id;
      $user_id=$request->user_id;
      $validate_data['user_id']=$user_id;


        $language_proficiency=Language_proficiency::updateOrCreate(['user_id'=>$user_id,'job_post_id'=>$validate_data['job_post_id']],$validate_data);
        if ($language_proficiency) {
          return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
        }
        return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);

      }
      public function get_job_posts()
      {
        // $job_posts=Job_post::get()->groupBy('programme');
        $job_posts=Job_post::get()->groupBy('programme');
        return response()->json(['job_posts'=>$job_posts, 'statusCode'=>200]);
      }
      public function get_all_job_posts()
      {
        $job_posts=Job_post::get();
        return response()->json(['job_posts'=>$job_posts, 'statusCode'=>200]);
      }
      public function get_required_qualifications(Request $request)
      {
        $personal_detail=Personal_detail::where('user_id', $request->user_id)->orderBy('id','desc')->first();
        $required_qualifications=Required_qualification::where('job_post_id', $personal_detail->job_post_id)->get();
        return response()->json(['required_qualifications'=>$required_qualifications, 'statusCode'=>200]);

      }
      public function get_diploma_names(Request $request)
      {
        $diploma_names=Diploma_name::where('required_qualification_id', $request->required_qualification_id)->get();
        return response()->json(['diploma_names'=>$diploma_names, 'statusCode'=>200]);

      }
      public function educational_qualification_save(Request $request)
      {
        // return $request->all();
        $validate_data=$request->validate([
            'job_post_id'=>'required',
            'user_id'=>'required',
            'degree'=>'required',
            'college'=>'required',
            'university'=>'required',
            'year_of_passing'=>'required',
            'percentage'=>'required',
        ]);
        $prev=Educational_qualification::where('user_id',$validate_data['user_id'])->where('job_post_id', $validate_data['job_post_id'])->get();
          if ($prev) {
            foreach ($prev as $key => $value) {
              $value->delete();
            }
            foreach ($validate_data['degree'][0] as $key => $value) {
              $degree_count=count($validate_data['degree'][0][$key]);
              $college_count=count($validate_data['college'][0][$key]);
              $university_count=count($validate_data['university'][0][$key]);
              $year_of_passing_count=count($validate_data['year_of_passing'][0][$key]);
              $percentage_count=count($validate_data['percentage'][0][$key]);
              if (gettype($validate_data['degree'][0][$key])=='integer') {
                $validate_data['degree'][0][$key]=Job_post::findOrFail($validate_data["job_post_id"])->name_of_post;
              }
              if ($degree_count!=0 && $college_count!=0 && $university_count!=0 && $year_of_passing_count!=0 && $percentage_count!=0) {
                $educational_qualifications=Educational_qualification::create(
                [
                  'user_id'=>$validate_data['user_id'],
                  'job_post_id'=>$validate_data['job_post_id'],
                  'degree'=>$validate_data['degree'][0][$key],
                  'college'=>$validate_data['college'][0][$key],
                  'university'=>$validate_data['university'][0][$key],
                  'year_of_passing'=>$validate_data['year_of_passing'][0][$key],
                  'percentage'=>$validate_data['percentage'][0][$key],
                ]);
              }
            }
          }
          else{
            foreach ($validate_data['degree'][0] as $key => $value) {
              $degree_count=count($validate_data['degree'][0][$key]);
              $college_count=count($validate_data['college'][0][$key]);
              $university_count=count($validate_data['university'][0][$key]);
              $year_of_passing_count=count($validate_data['year_of_passing'][0][$key]);
              $percentage_count=count($validate_data['percentage'][0][$key]);
              if (gettype($validate_data['degree'][0][$key])=='integer') {
                $validate_data['degree'][0][$key]=Job_post::findOrFail($validate_data["job_post_id"])->name_of_post;
              }
              if ($degree_count!=0 && $college_count!=0 && $university_count!=0 && $year_of_passing_count!=0 && $percentage_count!=0) {
                $educational_qualifications=Educational_qualification::create(
                [
                  'user_id'=>$validate_data['user_id'],
                  'job_post_id'=>$validate_data['job_post_id'],
                  'degree'=>$validate_data['degree'][0][$key],
                  'college'=>$validate_data['college'][0][$key],
                  'university'=>$validate_data['university'][0][$key],
                  'year_of_passing'=>$validate_data['year_of_passing'][0][$key],
                  'percentage'=>$validate_data['percentage'][0][$key],
                ]);
              }
            }
          }

          // $educational_qualifications=Educational_qualification::updateOrCreate(['user_id'=>$validate_data['user_id']],$validate_data);
          if ($educational_qualifications) {
            return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
          }
          return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);

        }
      public function computer_knowledge_save(Request $request)
      {
        // return $request->file('document_name')->getClientOriginalExtension();
        $validate_data=$request->validate([
            'job_post_id'=>'required',
            'user_id'=>'required',
            'name_of_diploma'=>'required',
            'institute'=>'required',
            'duration'=>'required',
            'document_name'=>'mimes:jpeg,jpg|required|max:100',
        ]);
        $file_name=$validate_data['document_name']->getClientOriginalName();
        $file_extension=$validate_data['document_name']->getClientOriginalExtension();

        $computer_skills=Computer_skill::updateOrCreate(['user_id'=>$validate_data['user_id'],'job_post_id'=>$validate_data['job_post_id']], $request->except('document_name'));
        if ($computer_skills) {
        $file_path='/uploads/computer_skills/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension;
        $computer_skills->Update(['document_name'=>'/uploads/computer_skills/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].$file_extension]) ;
        // $computer_skills=$validate_data['document_name']->storeAs('/uploads/computer_skills/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
        if(Storage::exists($file_path)){
          Storage::delete($file_path);
          $computer_skills=$validate_data['document_name']->storeAs('/uploads/computer_skills/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
        }
        else{
          $computer_skills=$validate_data['document_name']->storeAs('/uploads/computer_skills/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);

        }
        }

          if ($computer_skills) {
            return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
          }
          return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);

        }
      public function work_experience_save(Request $request)
      {
        $validate_data=$request->validate([
            'job_post_id'=>'required',
            'user_id'=>'required',
            'designation.*'=>'required',
            'organisation.*'=>'required',
            'from_date.*'=>'required',
            'document_name.*'=>'mimes:jpeg,jpg|required|max:100',
            'to_date.*'=>'required',
        ]);
        $files= $request->file('document_name');
        $prev=Work_experience::where('user_id', $validate_data['user_id'])->where('job_post_id', $validate_data['job_post_id'])->get();
        if(!$prev){
          foreach ($files as $key => $value) {
            $file_name=$validate_data['document_name'][$key]->getClientOriginalName();
            $file_extension=$validate_data['document_name'][$key]->getClientOriginalExtension();
            // return $file_extension;
            $work_experience=Work_experience::create([
              'job_post_id'=>$validate_data['job_post_id'],
              'user_id'=>$validate_data['user_id'],
              'designation'=>$validate_data['designation'][$key],
              'organisation'=>$validate_data['organisation'][$key],
              'from_date'=>$validate_data['from_date'][$key],
              'to_date'=>$validate_data['to_date'][$key]
            ]);
            if ($work_experience) {
            $file_path='/uploads/work_experience/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension;
            $work_experience->Update(['document_name'=>'/uploads/work_experience/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.$file_extension]) ;
            // $work_experience=$validate_data['document_name']->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
            if(Storage::exists($file_path)){
              Storage::delete($file_path);
              $work_experience=$validate_data['document_name'][$key]->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);
            }
            else{
              $work_experience=$validate_data['document_name'][$key]->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);

            }
            }
          }
        }
        else{
          foreach ($prev as $key => $value) {
            $value->delete();
          }
          foreach ($files as $key => $value) {
            $file_name=$validate_data['document_name'][$key]->getClientOriginalName();
            $file_extension=$validate_data['document_name'][$key]->getClientOriginalExtension();
            // return $file_extension;
            $work_experience=Work_experience::create([
              'job_post_id'=>$validate_data['job_post_id'],
              'user_id'=>$validate_data['user_id'],
              'designation'=>$validate_data['designation'][$key],
              'organisation'=>$validate_data['organisation'][$key],
              'from_date'=>$validate_data['from_date'][$key],
              'to_date'=>$validate_data['to_date'][$key]
            ]);
            if ($work_experience) {
            $file_path='/uploads/work_experience/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension;
            $work_experience->Update(['document_name'=>'/uploads/work_experience/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.$file_extension]) ;
            // $work_experience=$validate_data['document_name']->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
            if(Storage::exists($file_path)){
              Storage::delete($file_path);
              $work_experience=$validate_data['document_name'][$key]->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);
            }
            else{
              $work_experience=$validate_data['document_name'][$key]->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);

            }
            }
          }
        }

          if ($work_experience) {
            return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
          }
          return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);

        }

        public function document_save(Request $request)
        {
          $validate_data=$request->validate([
              'job_post_id'=>'required',
              'user_id'=>'required',
              'document_file.*'=>'mimes:jpeg,jpg|required|max:100',
              'document_name.*'=>'required',
          ]);

          $files= $request->file('document_file');
          $prev=Document_save::where('user_id', $validate_data['user_id'])->where('job_post_id', $validate_data['job_post_id'])->get();
          if(!$prev){
            foreach ($files as $key => $value) {
              $file_name=$validate_data['document_file'][$key]->getClientOriginalName();
              $file_extension=$validate_data['document_file'][$key]->getClientOriginalExtension();
              // return $file_extension;
              $document_save=Document_save::create([
                'job_post_id'=>$validate_data['job_post_id'],
                'user_id'=>$validate_data['user_id'],
                'document_name'=>$validate_data['document_name'][$key],
                'document_file'=>$validate_data['document_file'][$key],

              ]);
              if ($document_save) {
              $file_path='/uploads/'.$validate_data['document_name'][$key].'/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension;
              $document_save->Update(['document_file'=>'/uploads/'.$validate_data['document_name'][$key].'/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.$file_extension]) ;
              // $work_experience=$validate_data['document_file']->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
              if(Storage::exists($file_path)){
                Storage::delete($file_path);
                $work_experience=$validate_data['document_file'][$key]->storeAs('/uploads/'.$validate_data['document_name'][$key].'/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);
              }
              else{
                $work_experience=$validate_data['document_file'][$key]->storeAs('/uploads/'.$validate_data['document_name'][$key].'/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);

              }
              }
            }
          }
          else{
            foreach ($prev as $key => $value) {
              $value->delete();
            }
            foreach ($files as $key => $value) {
              $file_name=$validate_data['document_file'][$key]->getClientOriginalName();
              $file_extension=$validate_data['document_file'][$key]->getClientOriginalExtension();
              // return $file_extension;
              $document_save=Document_save::create([
                'job_post_id'=>$validate_data['job_post_id'],
                'user_id'=>$validate_data['user_id'],
                'document_name'=>$validate_data['document_name'][$key],
                'document_file'=>$validate_data['document_file'][$key],

              ]);
              if ($document_save) {
              $file_path='/uploads/'.$validate_data['document_name'][$key].'/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension;
              $document_save->Update(['document_file'=>'/uploads/'.$validate_data['document_name'][$key].'/'.$validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.$file_extension]) ;
              // $work_experience=$validate_data['document_file']->storeAs('/uploads/work_experience/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'.'.$file_extension);
              if(Storage::exists($file_path)){
                Storage::delete($file_path);
                $work_experience=$validate_data['document_file'][$key]->storeAs('/uploads/'.$validate_data['document_name'][$key].'/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);
              }
              else{
                $work_experience=$validate_data['document_file'][$key]->storeAs('/uploads/'.$validate_data['document_name'][$key].'/', $validate_data['user_id'].'_'.$validate_data['job_post_id'].'_'.$key.'.'.$file_extension);

              }
              }
            }
          }

            if ($document_save) {
              return response()->json(['message'=>'Data Saved Successfully', 'statusCode'=>200]);
            }
            return response()->json(['message'=>'Something went wrong', 'statusCode'=>502]);
        }
        public function get_districts(Request $request)
        {
          $districts=District::with('blocks')->get();
          return response()->json(['districts'=>$districts, 'statusCode'=>200]);

        }
        public function get_panchayats(Request $request)
        {
          $panchayats=Gram_panchyat::where('block_id', $request->block_id)->get();
          return response()->json(['panchayats'=>$panchayats, 'statusCode'=>200]);

        }

}
