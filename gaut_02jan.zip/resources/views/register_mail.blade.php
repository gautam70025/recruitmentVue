
  <p>Hello {{$data['name']}}, you have been registered successfully for P&RD Recruitment Portal.</p>
  <p>Your login details are stated below:</p>
  <p>User Id: <b>{{$data['registration_no']}}</b></p>
  <p>Password: <b>{{$data['password']}}</b></p>
