<template>
  <div class="header" v-if="!$route.meta.hideHeader">
    <!-- <div class="container-fluid"> -->
    <img src="images/banner_new.png" alt="img" width="100%" />

    <!-- <div class="row header-banner">
        <div class="col-md-2 content">
          <img src="images/sird_logo_1.png" alt="img" />
        </div>
        <div class="col-md-8 content text-content">
          <p class="desk">Panchayat & Rural Development</p>
          <p class="mob">P&RD</p>
          <p>Recruitment Portal</p>
        </div>
        
      </div> -->
    <!-- </div> -->
  </div>
</template>
<script>
export default {};
</script>

